#!/bin/bash
#chmod -R 644 /var/www/html/Wordpress
chown -R apache: /var/www/html/index.html
