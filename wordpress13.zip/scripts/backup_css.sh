#!/bin/bash
#cp /var/www/html/Wordpress/wp-content/themes/twentyfourteen/style.css /var/www/html/Wordpress/wp-content/themes/twentyfourteen/style.css.org
#chown apache: /var/www/html/Wordpress/wp-content/themes/twentyfourteen/style.css.org
rm -f /var/www/html/Wordpress/wp-content/themes/twentyfourteen/style.css
